import sys, time, os
from colored import fg, bg, attr

def start():
   print ("\033[1;93m  [?] \033[1;0mChoose Platform\n")
   print ("\033[1;32m  [1]\033[1;0mKali LinuxTerminal  :    [Laptop, Desktop computer ...etc]")
   print ("\033[1;32m  [2]\033[1;0mTermux Terminal     :    [Android phones, tablets ...etc ]\n")
   choice = raw_input("  %s%sChoice%s > " % (fg('black'), bg(160), attr(0)))
   print ""

   if choice == '1':
     print ("\033[1;32m  [+] Installing Hydra on Kali\033[0m")
     time.sleep(1.1)
     print "=" * 47
     os.system("sudo apt-get install hydra")
     print "#" * 47
     print("  \033[1;32m[+]\033[0m Done Installing!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""

   elif choice == '2':
     print ("\033[1;32m  [+] Installing Hydra on Termux\033[0m")
     time.sleep(1.1)
     print "=" * 47
     os.system("pkg install hydra")
     print "#" * 47
     print("  \033[1;32m[+]\033[0m Done Installing!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""

   elif choice == 'main':
     print ""

   else:
     print("\033[1;31m[-]\033[1;0m Out Of Choice")
     time.sleep(1.5)
     print ""