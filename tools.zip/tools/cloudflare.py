import urllib, time, os, sys, requests, socket
from colored import fg, bg, attr



def scan():
   try:

   # Getting Target

     print ("\nEnter Target [ www.target.com / target.com ] \n")
     host = raw_input("  %s%sHost%s > " % (fg('black'), bg(160), attr(0)))
     if host == 'main':
       print ""
     else:
       try:

   # Getting Info

         print ("\n  %s%sGetting Info...%s\n" % (fg('black'), bg('green'), attr(0)))
         time.sleep(2.5)
         url = socket.gethostbyname(host)
         targ = "http://"+url
         r = requests.get(targ)
         http = r.status_code
         print (" \033[32m [ IP Address    ]\033[0m : %s%s%s%s" % (fg('black'), bg('green'), url, attr(0)))
         print (" \033[32m [ status code   ]\033[0m : %s%s%s%s" % (fg('black'), bg('green'), http, attr(0)))

   # Exception

       except requests.ConnectionError as (msg):
         print ("\033[31m[Error] \033[33merror sending requests") + "\033[0m"
         time.sleep(1.5)
         start()


   # Start Scanning Cloudflare

       print ""
       try:
            data = "http://"+host #+'/'
            site = urllib.urlopen(data)
            sourcecode = site.read()

   # Result

            if "used CloudFlare to restrict access</title>" in sourcecode:
                 print("\n\033[31m  [ Cloudflare Detected ]")
                 print("\033[37m  [status] : %s%scloudflare blocked the ip%s" % (fg('blacl'), bg(160), attr(0)))
            else:
                 print("\n\033[32m  [ No Cloudflare Detected ]")
                 print("\033[32m  [status] : %s%sGood%s" % (fg('black'), bg('green'), attr(0)))

   # Exception

       except IOError:
            print ("\n\033[31[Error] \033[33Connection Error\033[0m\n")
            time.sleep(1.1)
            scan()

   # End Or New Output

       ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
       if ex == 'n' or ex == 'N':
           sys.exit()

       elif ex == 'y' or ex == 'Y':
           print ""


   # Exception

   except IOError:
       print ("\n\033[31m[Error] \033[33mConnection Error\033[0m\n")
       time.sleep(1.1)
       scan()
   except requests.ConnectionError as (msg):
       print ("\n\033[31m[Error] \033[33mCant Send Requests\033[0m\n")
       time.sleep(1.1)
       scan()