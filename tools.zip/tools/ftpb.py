import os, sys
from colored import fg, bg, attr


def start():

   # Getting Target

   user = raw_input("\n  %s%sUser%s > " % (fg('black'), bg(160), attr(0)))
   print ""
   if user == 'main':
     print ""
   else:
     iphost = raw_input("  %s%sIPHost%s > " % (fg('black'), bg(160), attr(0)))
     word = raw_input("\n  %s%sWordlist%s > " % (fg('black'), bg(160), attr(0)))

   # Starting To Crack

     print ""
     print "=" * 47
     os.system("hydra -l %s -P %s %s ftp" % (user, word, iphost))
     print "#" * 47
     print ("\n\033[1;32m[+]\033[0m process done!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""