import socket ,requests ,os ,time ,sys ,random
from colored import fg, bg ,attr

   # Starting Programs Output

def lulz():
   try:

      # Getting Target

     f = open("lulz.txt","r");
     print ("\nEnter Target [ www.target.com / target.com ] \n")
     target = raw_input("  %s%sTarget Host%s > " % (fg('black'), bg(160), attr(0)))
     if target == 'main':
       print ""
     else:

   # Scanning And Getting Info

       print ("\n  %s%sGetting Info...%s\n" % (fg('black'), bg('green'), attr(0)))
       time.sleep(2.5)
       url = socket.gethostbyname(target)
       host = "http://"+url
       r = requests.get(host)
       http = r.status_code
       print (" \033[32m [ IP Address    ]\033[0m : %s%s%s%s" % (fg('black'), bg('green'), url, attr(0)))
       print (" \033[32m [ status code   ]\033[0m : %s%s%s%s" % (fg('black'), bg('green'), http, attr(0)))

   # Scanning For Admin Panels

       print "\n"
       time.sleep(1.5)
       print "\033[32m[+] Finding Admin Panel...\033[0m\n"
       print ("\033[32m      Status           :            link        \033[0m\n")
       for x in range (1, 482):
         try:
           sub_link = f.readline()
           plurl = "http://"+target+sub_link
           C = requests.get(plurl)
           statcode = C.status_code
           if statcode == 200:
              print ("\033[32m[+] Admin panel found! : %s%s%s%s\033[0m\033[0m\033[0m\033[0m" % (fg('black'), bg('green'), plurl, attr(0)))
           else:
              print ("\033[31m[-] Error Panel        : %s" % (plurl))

   # Exception

         except requests.ConnectionError as (msg):
            print ""

   # Exit

       print ("\033[32m  [ Scanning Admin Panel Done! ]\033[0m")
       ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))

   # New Or End Function

       if ex == 'n' or ex == 'N':
           start()

       elif ex == 'y' or ex == 'Y':
           print ""

   # Exception

   except socket.error as (msg):
     print ("\033[31m[Error] \033[33mconnection lost") + "\033[0m"
     time.sleep(1.5)
     start()
   except socket.gaierror as (msg):
     print ("\033[31m[Error] \033[33merror connecting to socket") + "\033[0m"
     time.sleep(1.5)
     start()


def start():

   # Starting The Program

       lulz()