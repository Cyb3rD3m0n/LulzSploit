import sys, time, os
from colored import fg, bg, attr

def start():
   print ("\n\033[1;93m  [?] \033[1;0mChoose Platform [Installer]\n")
   print ("\033[1;32m  [1]\033[1;0mKali LinuxTerminal  :    [Laptop, Desktop computer ...etc]")
   print ("\033[1;32m  [2]\033[1;0mTermux Terminal     :    [Android phones, tablets ...etc ]\n")
   print ("\n\033[1;32m  [start] \033[1;0mconnect to tor network")
   choice = raw_input("\n  %s%sChoice%s > " % (fg('black'), bg(160), attr(0)))
   print ""

   if choice == '1':
     time.sleep(1.5)
     print ("\033[1;32m  [+] Installing Tor on Kali\033[0m")
     time.sleep(1.1)
     print "=" * 47
     os.system("sudo apt-get install tor")
     print "#" * 47
     print("  \033[1;32m[+]\033[0m Done Installing!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""

   elif choice == '2':
     time.sleep(1.5)
     print ("\033[1;32m  [+] Installing tor on Termux\033[0m")
     time.sleep(1.1)
     print "=" * 47
     os.system("pkg install tor")
     print "#" * 47
     print("  \033[1;32m[+]\033[0m Done Installing!")
     ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
     if ex == 'n' or ex == 'N':
        sys.exit()

     elif ex == 'y' or ex == 'Y':
        print ""

   elif choice == 'start':
      time.sleep(1.5)
      print ""
      print ("\n  \033[32m[+]\033[0m use ctrl + c to stopped connection\n")
      print "=" * 47
      print ("  \033[32m[+] Checking Net Status\033[0m")
      print "=" * 47
      os.system("netstat -tupln")
      print "#" * 47
      time.sleep(1.5)
      print ("  \033[32m[+] Connecting to TOR Network\033[0m")
      print "=" * 47
      os.system("tor")
      print "#" *47
      print ("\n\033[32m  [ process done! ]\033[0m")
      ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))
      if ex == 'n' or ex == 'N':
         sys.exit()

      elif ex == 'y' or ex == 'Y':
         print ""

   elif choice == 'main':
     print ""

   else:
     print("\033[1;31m[-]\033[1;0m Out Of Choice")
     time.sleep(1.5)
     print ""