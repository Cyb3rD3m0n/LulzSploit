import whois, time
from colored import fg, bg, attr


def start():
   try:

   # Getting Target

      print ("\nEnter Target [ www.target.com / target.com ] \n")
      domain = raw_input("  %s%sTarget Host%s > " % (fg('black'), bg(160), attr(0)))
      if domain == 'main':
        print ""
      else:
        print ("\n\033[32m  [ Getting Whois Query ]\033[0m\n")
        time.sleep(1.5)
        w = whois.query(domain)
        print ("  \033[32m[+]\033[0mdomain name        : {}".format(w.name))
        time.sleep(1.5)
        print ("  \033[32m[+]\033[0mcreation date      : {}".format(w.creation_date))
        time.sleep(1.5)
        print ("  \033[32m[+]\033[0mexpiration date    : {}".format(w.expiration_date))
        time.sleep(1.5)
        print ("  \033[32m[+]\033[0mlast updated       : {}".format(w.last_updated))
        time.sleep(1.5)
        print ("  \033[32m[+]\033[0mregistrar          : {}".format(w.registrar))

   # New Or End Function

        ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))

        if ex == 'n' or ex == 'N':
           start()

        elif ex == 'y' or ex == 'Y':
           print ""

   # Exception

   except IOError:
        print ("\033[31m[Error] \033[33merror connecting to site") + "\033[0m"