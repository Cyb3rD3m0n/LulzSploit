import whois, time, collections
from colored import fg, bg, attr

def rem(w):
  empty = ""
  if "',[,]" in w:
    return empty

def start():
   try:

   # Getting Target

      print ("\nEnter Target [ www.target.com / target.com ] \n")
      domain = raw_input("  %s%sTarget Host%s > " % (fg('black'), bg(160), attr(0)))
      if domain == 'main':
        print ""
      else:
        print ("\n\033[32m  [ Getting Whois Query ]\033[0m\n")
        time.sleep(1.5)
        w = whois.whois(domain)
        print ("  \033[32m[+]\033[0mname               :  \n\n  {}\n".format(w.name))
        print ("  \033[32m[+]\033[0mcreation date      :  \n\n  {}\n".format(w.creation_date))
        print ("  \033[32m[+]\033[0mexpiration date    :  \n\n  {}\n".format(w.expiration_date))
        print ("  \033[32m[+]\033[0mlast updated       :  \n\n  {}\n".format(w.last_updated))
        print ("  \033[32m[+]\033[0mregistrar          :  \n\n  {}\n".format(w.registrar))
        print ("  \033[32m[+]\033[0memails             :  \n\n  {}\n".format(w.emails))
        print ("  \033[32m[+]\033[0morganization       :  \n\n  {}\n".format(w.org))
        print ("  \033[32m[+]\033[0maddress            :  \n\n  {}\n".format(w.address))
        print ("  \033[32m[+]\033[0mcity               :  \n\n  {}\n".format(w.city))
        print ("  \033[32m[+]\033[0mcountry            :  \n\n  {}\n".format(w.country))
        print ("  \033[32m[+]\033[0mzip code           :  \n\n  {}\n".format(w.zip_code))
        print ("  \033[32m[+]\033[0mname servers       :  \n\n  {}\n".format(w.name_servers))

   # New Or End Function

        ex = raw_input("\n  %s%sdo you want to back in main program [ Y/n ]%s > " % (fg('black'), bg(160), attr(0)))

        if ex == 'n' or ex == 'N':
           sys.exit()

        elif ex == 'y' or ex == 'Y':
           print ""

   # Exception

   except IOError:
        print ("\033[31m[Error] \033[33merror connecting to site") + "\033[0m"
        time.sleep(1.5)
        start()


